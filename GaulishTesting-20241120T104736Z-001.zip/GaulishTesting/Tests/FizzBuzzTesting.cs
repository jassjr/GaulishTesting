namespace Tests;

public class FizzbuzzTesting
{
    [Theory]
    [InlineData(3, "Asterix")]
    [InlineData(5, "Obelix")]
    [InlineData(15, "AsterixObelix")]
    [InlineData(4, "4")]
    public void FizzBuzzTest(int n, string expected)
    {
        string actual = FizzBuzz.AsterixObelix(n);
        Assert.Equal(expected, actual);
    }
}