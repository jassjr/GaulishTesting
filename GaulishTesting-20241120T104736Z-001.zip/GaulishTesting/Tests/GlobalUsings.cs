global using Xunit;

global using GaulishTesting;
global using GaulishTesting.Codafix;