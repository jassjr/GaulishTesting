namespace GaulishTesting.Codafix
{
    public class FizzBuzz
    {
        public static string AsterixObelix(int n)
        {
            if (n % 15 == 0)
            {
                return "AsterixObelix";
            }
            else if (n % 3 == 0)
            {
                return "Asterix";
            }
            else if (n % 5 == 0)
            {
                return "Obelix";
            }
            else
            {
                return n.ToString();
            }
        }
    }
}