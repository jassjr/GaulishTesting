namespace GaulishTesting.Codafix
{
    public class Terminatorix
    {
        public static string BoupBip(string magicString, int magicNumber)
        {
            Console.WriteLine("Boup bip, I'm the first method you will need " +
                              "to debug!\n Don't forget to read the error message");
            Console.WriteLine("magicString");
            Console.WriteLine(magicString);
            return (MagicCalculus(magicNumber, magicString) + 4).ToString();
        }

        // --------------------------------------------------------------------------
        // The code below SHOULD NOT be modified
        public static int MagicCalculus(int k, string s)
        {
            return k + s.Length;
        }
    }
}