namespace GaulishTesting.Codafix
{
    public class Idefix
    {
        public static bool IsBoneNorth(int idefixY, int boneY)
        {
            if (idefixY > boneY)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool IsBoneSouth(int idefixY, int boneY)
        {
            if (idefixY < boneY)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool IsBoneWest(int idefixX, int boneX)
        {
            if (idefixX > boneX)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool IsBoneEast(int idefixX, int boneX)
        {
            if (idefixX < boneX)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool IsOnBone(int idefixX, int idefixY,
                                    int boneX, int boneY)
        {
            if (idefixX == boneX && idefixY == boneY)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static string NextDirection(int idefixX, int idefixY,
                                           int boneX, int boneY)
        {
            if (IsOnBone(idefixX, idefixY, boneX, boneY))
            {
                return "Idefix is already over his bone!";
            }

            if (IsBoneNorth(idefixY, boneY))
            {
                if (IsBoneWest(idefixX, boneX))
                {
                    return "NW";
                }
                else if (IsBoneEast(idefixX, boneX))
                {
                    return "NE";
                }

                return "N";
            }
            else
            {
                if (IsBoneWest(idefixX, boneX))
                {
                    return "SW";
                }
                else if (IsBoneEast(idefixX, boneX))
                {
                    return "SE";
                }

                return "S";
            }
        }
    }
}