namespace GaulishTesting.MathObelix;

public class Romanix
{
    public static string AreSoldiersSafe(bool isAsterixOrObelixHere)
    {
        if (isAsterixOrObelixHere)
        {
            return "We should hide behind those trees.";
        }
        else
        {
           return "We are safe for now.";
        }
    }

    public static string GaulishDefenseStrategy(int nbRomanSoldiers)
    {
        if (nbRomanSoldiers > 0 && nbRomanSoldiers < 10)
            return "Let's just send Idefix, he'll take care of them.";
        
        else if (nbRomanSoldiers >= 10 && nbRomanSoldiers < 100)
            return "Let's just send Asterix and Obelix to play with them."; 
        
        else if (nbRomanSoldiers >= 100 && nbRomanSoldiers < 10000)
            return "All hands on deck!";
        else
            return "Obelix! For once we'll allow you to have a tee spoon of magic potion."; 
    }

    public static string RomanSoldierReaction(string thingEncountered)
    {
        switch (thingEncountered)
        {
            case "Asterix": 
                return "Hope he didn't see us...";

            case "Obelix":
                return "WE'RE COOKED"; 
        
            case  "A wild boar" :
                return "RUN FOR YOUR LIFE!"; 
            default:
                return "Aaaaaahhh!";
        }

    }

}                           