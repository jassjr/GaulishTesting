namespace GaulishTesting.Profix
{
    public class Calculus
    {
        public static int RomanSoldiersNumber(int nbRomanSoldiersAvailable, bool isTargetAsterixVillage)
        {
            if (nbRomanSoldiersAvailable == 0)
            {
                return -1;
            }
            else if (isTargetAsterixVillage)
            {
                return nbRomanSoldiersAvailable;
            }
            else
            {
                int soldiersToSend = nbRomanSoldiersAvailable / 3;

                if (nbRomanSoldiersAvailable % 3 != 0)
                {
                    soldiersToSend += 1;
                }

                return soldiersToSend;
            }
        }

        public static int GetMinutes(long timeInSeconds)
        {
            int tot_min = (int)(timeInSeconds / 60);
            int minutes = tot_min % 60;

            return minutes;
        }
    }
}
