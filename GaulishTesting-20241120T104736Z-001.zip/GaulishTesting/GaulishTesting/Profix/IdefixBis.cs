namespace GaulishTesting.Profix;

public class IdefixBis
{

    public static string SmartNextDirection(int idefixX, int idefixY,
        int boneX, int boneY,
        int rockX, int rockY,
        int treeX, int treeY)
    {
        if (idefixX == boneX && idefixY == boneY)
        {
            return "Diggy Diggy Hole";
        }

        string direction = GetDirectionToBone(idefixX, idefixY, boneX, boneY);

        if (IsObstacleInDirection(idefixX, idefixY, direction, rockX, rockY, treeX, treeY))
        {
            direction = GetAlternativeDirection(direction, idefixX, idefixY, boneX, boneY, rockX, rockY, treeX, treeY);
        }

        return direction;
    }

    private static string GetDirectionToBone(int idefixX, int idefixY, int boneX, int boneY)
    {
        string horizontal = "";
        string vertical = "";

        if (idefixX < boneX) horizontal = "East";
        else if (idefixX > boneX) horizontal = "West";

        if (idefixY < boneY) vertical = "South";
        else if (idefixY > boneY) vertical = "North";

        return vertical + (vertical != "" && horizontal != "" ? "-" : "") + horizontal;
    }

    private static bool IsObstacleInDirection(int idefixX, int idefixY, string direction, int rockX, int rockY,
        int treeX, int treeY)
    {
        int nextX = idefixX;
        int nextY = idefixY;

        switch (direction)
        {
            case "North":
                nextY--;
                break;
            case "North-East":
                nextY--;
                nextX++;
                break;
            case "East":
                nextX++;
                break;
            case "South-East":
                nextY++;
                nextX++;
                break;
            case "South":
                nextY++;
                break;
            case "South-West":
                nextY++;
                nextX--;
                break;
            case "West":
                nextX--;
                break;
            case "North-West":
                nextY--;
                nextX--;
                break;
        }

        return (nextX == rockX && nextY == rockY) || (nextX == treeX && nextY == treeY);

        private static string GetAlternativeDirection(string originalDirection, int idefixX, int idefixY, int boneX,
            int boneY, int rockX, int rockY, int treeX, int treeY)
        {

            switch (originalDirection)
            {
                case "North-East":
                    return !IsObstacleInDirection(idefixX, idefixY, "North", rockX, rockY, treeX, treeY)
                        ? "North"
                        : "East";
                case "North-West":
                    return !IsObstacleInDirection(idefixX, idefixY, "North", rockX, rockY, treeX, treeY)
                        ? "North"
                        : "West";
                case "South-East":
                    return !IsObstacleInDirection(idefixX, idefixY, "South", rockX, rockY, treeX, treeY)
                        ? "South"
                        : "East";
                case "South-West":
                    return !IsObstacleInDirection(idefixX, idefixY, "South", rockX, rockY, treeX, treeY)
                        ? "South"
                        : "West";
                case "North":
                    return !IsObstacleInDirection(idefixX, idefixY, "North-West", rockX, rockY, treeX, treeY)
                        ? "North-West"
                        : "North-East";
                case "South":
                    return !IsObstacleInDirection(idefixX, idefixY, "South-West", rockX, rockY, treeX, treeY)
                        ? "South-West"
                        : "South-East";
                case "East":
                    return !IsObstacleInDirection(idefixX, idefixY, "South-East", rockX, rockY, treeX, treeY)
                        ? "South-East"
                        : "North-East";
                case "West":
                    return !IsObstacleInDirection(idefixX, idefixY, "South-West", rockX, rockY, treeX, treeY)
                        ? "South-West"
                        : "North-West";
            }

            return originalDirection;
        }
    }
}
