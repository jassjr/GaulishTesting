﻿// See https://aka.ms/new-console-template for more information

using GaulishTesting;
using GaulishTesting.Codafix;
using GaulishTesting.MathObelix;
using GaulishTesting.Profix;

/*Console.WriteLine("Hello, World!");*/

/*string helloVillage = Hello.HelloVillage();  // hello == "Hello, Village!"
Console.WriteLine(helloVillage);
Console.Write(helloVillage);
Console.Write(helloVillage);*/


/*string helloIdefix = Hello.HelloIdefix(); // helloIdefix == "Hello Idefix!\nDo you want to go for a walk ?"
Console.WriteLine(helloIdefix);
Console.WriteLine(helloIdefix);*/


/*string helloYou = Hello.HelloYou("Obelix"); // helloYou == "Hello Obelix!"
Console.WriteLine(helloYou);*/


/*int birth = Calculatorix.Birth(3); // birth == 4
Console.WriteLine(birth);*/

/*bool isEven = Calculatorix.isEven(2); // isEven == True
Console.WriteLine(isEven);*/

/*string soldiersAction = Romanix.AreSoldiersSafe(true); // soldiersAction == "We should hide behind those trees."
Console.WriteLine(soldiersAction);*/ 

/*string gaulishDefenseStrategy = Romanix.GaulishDefenseStrategy(4); // gaulishDefenseStrategy == "Let's just send Idefix, he'll take care of them."
Console.WriteLine(gaulishDefenseStrategy);*/


string romanSoldierReaction = Romanix.RomanSoldierReaction("A wild boar"); // romanSoldierReaction == "RUN FOR YOUR LIFE!"
Console.WriteLine(romanSoldierReaction);


string boupbip = Terminatorix.BoupBip("Test.", 9); // boupbip == "18"
Console.WriteLine(boupbip);
string boupbip2 = Terminatorix.BoupBip("Vous savez, je ne pense pas qu'il y ait de bon ou de mauvais code.", 0); // boupbip == "70"
Console.WriteLine(boupbip2);

string nextDirection = Idefix.NextDirection(0, 0, 0, 0); // nextDirection == "Idefix is already over his bone!"
Console.WriteLine(nextDirection);

int romanSoldierNumber = Calculus.RomanSoldiersNumber(1234, true); // romanSoldierNumber == 1234
Console.WriteLine(romanSoldierNumber);

int minutes = Calculus.GetMinutes(56264); // minutes == 37
Console.WriteLine(minutes);

string smartDirection = IdefixBis.SmartNextDirection(0,0,0,0,1,1,2,2); // smartDirection == "Diggy Diggy Hole"
Console.WriteLine(smartDirection);