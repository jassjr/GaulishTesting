namespace GaulishTesting;

public class Hello
{
    public static string HelloVillage()
    {
        return "Hello, Village!"; 
    }

    public static string HelloIdefix()
    {
        return "Hello Idefix!\nDo you want to go for a walk ?"; 
    }

    public static string HelloYou(string name)
    {
        return $"Hello {name}!";

    }

}