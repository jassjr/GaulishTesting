namespace GaulishTesting.Codafix;

public class Terminatorix
{
    public static int BoupBip(int magicString, string magicNumber)
    {
        Console.WriteLine("Boup bip, I'm the first method you will need " +
                          "to debug!\n Don't forget to read the error message");
        Console.WriteLine("magicString");
        Console.WriteLine(magicString);
        return MagicCalculus(magicString, magicNumber) + 4;
    }

    // --------------------------------------------------------------------------
    // The code below SHOULD NOT be modified
    public static int MagicCalculus(int k, string s)
    {
        return k + s.Length;
    }
}