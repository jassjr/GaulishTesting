namespace GaulishTesting.MathObelix;

public class Calculatorix
{
    public static int Birth(int nbInhabitants)
    {
        return (nbInhabitants + 1);
        
    }
    public static bool isEven(int n)
    {
        return (n % 2 == 0);
    }

}


