global using Xunit;

global using GaulishTesting;