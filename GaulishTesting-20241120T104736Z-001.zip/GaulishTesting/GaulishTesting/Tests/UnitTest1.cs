using GaulishTesting;

namespace Tests;

public class UnitTest1
{
    [Fact]
    public void HelloVillage_Test()
    {
        string hello = Hello.HelloVillage(); // call of the method
        Assert.Equal("Hello, Village!", hello); // assertion to check hello
    }
    
    [Theory]                                     // a theory is a test that takes multiple inputs
    [InlineData("Asterix", "Hello Asterix!")]    // args match the method signature, here: (string str, string expected)
    [InlineData("", "Hello !")]
    public void HelloYouTest(string str, string expected)
    {
        string actual = Hello.HelloYou(str);
        Assert.Equal(expected, actual);          // test that actual == expected
    }

}

